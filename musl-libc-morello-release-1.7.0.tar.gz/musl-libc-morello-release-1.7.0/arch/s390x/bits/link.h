typedef uint64_t Elf_Symndx;
