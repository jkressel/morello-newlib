#undef FIOQSIZE
#define FIOQSIZE 0x545e
